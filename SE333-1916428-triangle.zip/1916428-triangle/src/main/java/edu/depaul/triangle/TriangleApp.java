/* 
 * Assignment: #3
 * Topic: Identifying Triangles
 * Author: <YOUR NAME>
 */

package edu.depaul.triangle;

import static edu.depaul.triangle.TriangleType.EQUILATERAL;
import static edu.depaul.triangle.TriangleType.ISOSCELES;
import static edu.depaul.triangle.TriangleType.SCALENE;

import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is a rudimentary user interface for the Triangle classificatin
 * problem.  It collects a string of sides from the user and attempts to use
 * it as parameters for creating a Triangle.
 */
public class TriangleApp {

  private static final Logger logger = LoggerFactory.getLogger(Triangle.class);
    
  private String[] getArgs(Scanner scanner) {
    System.out.println("press Enter by itself to quit");
    System.out.println("enter 3 integers separated by space.");
    String args = scanner.nextLine();
    return args.split(" ");
  }
  
  public void run() {
    try (Scanner scanner = new Scanner(System.in)) {
      String[] args = getArgs(scanner);
      while (args[0].length() != 0) {
        try {
          Triangle t = new Triangle(args);
          TriangleType triClass = t.classify();
          System.out.println("Triangle type: " + triClass);
        } catch (IllegalArgumentException e) {
          logger.error("Invalid input: " + e.getMessage());
        }
        args = getArgs(scanner);
      }
      System.out.println("Done");
    }
  }

  public static void main(String[] args) {
    new TriangleApp().run();
  }
}
