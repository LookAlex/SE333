/*
 * Assignment: #3
 * Topic: Identifying Triangles
 * Author: <YOUR NAME>
 */
package edu.depaul.triangle;

/**
 * Names of triangle types
 */
public enum TriangleType {
  EQUILATERAL,
  ISOSCELES,
  SCALENE
}
