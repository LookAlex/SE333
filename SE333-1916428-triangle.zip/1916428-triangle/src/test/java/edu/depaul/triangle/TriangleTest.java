/*
 * Assignment: #3
 * Topic: Identifying Triangles
 * Author: <YOUR NAME>
 */
package edu.depaul.triangle;

import static org.junit.jupiter.api.Assertions.*;
import static edu.depaul.triangle.TriangleType.ISOSCELES;
import static edu.depaul.triangle.TriangleType.EQUILATERAL;
import static edu.depaul.triangle.TriangleType.SCALENE;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TriangleTest {
  @Test
  @DisplayName("2a Asserts an equilateral triangle")
  void equilateral(){
    Triangle type= new Triangle(new String[]{"4","4","4"});
    assertEquals(EQUILATERAL,type.classify());
  }
  @Test
  @DisplayName("2a Asserts a scalene triangle")
  void scalene(){
    Triangle type= new Triangle(new String[]{"3","4","5"});
    assertEquals(SCALENE,type.classify());
  }
  @Test
  @DisplayName("2b Asserts an isosceles triangle but fails called a scalene instead")
  void isosceles(){
    Triangle type= new Triangle(new String[]{"6","8","6"});
    assertEquals(ISOSCELES,type.classify());
  }

  @Test
  @DisplayName("2c Invalid Input into Triangle")
  public void invalid_inputs() {
    String[] args = {"1","B","3"};
    assertThrows(IllegalArgumentException.class,() -> new Triangle(args),"Inserted a character instead of all numerical values");
  }
  @Test
  @DisplayName("2d Negative triangle test")
  void triangle_theorem(){
    String[]args={"-1","2","3"};
    assertThrows(IllegalArgumentException.class,()->new Triangle (args),"Triangle cannot have negative inputted sides");
  }
}
