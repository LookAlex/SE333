package edu.depaul.se433.coverage;

public class Test1 {

}
