/* 
 * Assignment #4
 * Topic: Mocks
 * Author: Alex Look
 */
package edu.depaul.se433.fileservice;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Fulfill the assignment by adding tests to this class
 */
class FileMonitorTest {
    @Test
    @DisplayName("Testing the mock service with .tmp files")
    void tmp_exists() {
        FileService mockServer = mock(FileService.class);
        when(mockServer.getDirectoryContents(anyString())).thenReturn(Arrays.asList("text1.tmp","text2.tmp","text3.tmp","text4.tmp","text5.tmp","text6.tmp","text7.tmp","text8.tmp","text9.tmp","text10.tmp"));
        FileMonitor monitorService=new FileMonitor(mockServer);
        monitorService.clean(".");
        verify(mockServer,times(10)).delete(anyString());
    }
    @Test
    @DisplayName("Testing the mock service with no .tmp files")
    void tmp_does_not_exists() {
        FileService mockserver = mock(FileService.class);
        when(mockserver.getDirectoryContents(anyString())).thenReturn(Arrays.asList("text1.txt","text2.txt","text3.txt","text4.txt","text5.txt","text6.txt","text7.txt","text8.txt","text9.txt","text10.txt"));
        FileMonitor monitorService=new FileMonitor(mockserver);
        monitorService.clean(".");
        verify(mockserver,times(0)).delete(anyString());
    }

    @Test
    @DisplayName("Testing the mock service with an exception")
    void temp_Exception() {
       FileService mockserver = mock(FileService.class);
       when(mockserver.getDirectoryContents(anyString())).thenReturn(Arrays.asList("text1.tmp","text2.txt","text3.tmp","text4.txt","text5.tmp","text6.txt","text8.tmp","text9.txt","text10.tmp"));
       FileMonitor monitorService = new FileMonitor(mockserver);
       try {
           monitorService.clean(".");
       } catch (Exception e) {
           verify(mockserver,times(5)).delete(anyString());
       }
}
}
