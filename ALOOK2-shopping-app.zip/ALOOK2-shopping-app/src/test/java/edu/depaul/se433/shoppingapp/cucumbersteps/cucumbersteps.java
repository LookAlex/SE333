package edu.depaul.se433.shoppingapp.cucumbersteps;

import edu.depaul.se433.shoppingapp.ShippingType;
import edu.depaul.se433.shoppingapp.TotalCostCalculator;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class cucumbersteps {
        double cost = 0;
        String state = "";
        String shipping;

        private TotalCostCalculator calculator = new TotalCostCalculator();


        @Given("User buys a total of {double} of items")
        public void price_of_items(Double double1) {
            if (cost >= 50.0) {
                cost = double1;
            }
        }

        @And("User lives in IL, CA, or NY a {string} that taxes")
        public void state_tax(String state) {
            this.state = state;
        }

        @And("User wants {string} shipping")
        public void shipping_type(String shipping) {
            if (shipping.contains(" "))
                shipping = shipping.replace(" ", "_");
            this.shipping = shipping;
        }

        @Then("Bill with tax is {double} dollars and no shipping cost")
        public void expected_result(double double1) {
            double result = (double) TotalCostCalculator.calculate(55.00, "IL", ShippingType.STANDARD);
            assertEquals(58.3, result);
        }
    }

