package edu.depaul.se433.shoppingapp;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.tomcat.jni.Local;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.time.*;
import java.util.*;

import static org.mockito.Mockito.*;


public class MockTests {
    @Test
    @DisplayName("Testing of saving an item, shipping, tax, and total into the database system")
    void saving_purchases(){
        PurchaseDBO recordPurchase=mock(PurchaseDBO.class);
        PurchaseAgent savepurchase=new PurchaseAgent(recordPurchase);
        Bill receipt=new Bill(50,10,0.06,63.6);
        Purchase list=Purchase.make("Alex",LocalDate.now(),receipt.total(),"NY","STANDARD");
        savepurchase.save(list);
        verify(recordPurchase,times(1)).savePurchase(list);
    }
    @Test
    @DisplayName("Testing to save an entry that contains nothing to return nothing")
    void getting_purchases(){
        PurchaseDBO getpurchase=mock(PurchaseDBO.class);
        PurchaseAgent agent=new PurchaseAgent(getpurchase);
        ArrayList<Purchase> buylist=new ArrayList<>();
        Purchase entry=Purchase.make("Kian",LocalDate.now(),14.00,"NY","STANDARD");
        buylist.add(entry);
        when(getpurchase.getPurchases()).thenReturn(buylist);
        assertEquals(buylist,agent.getPurchases());
        verify(getpurchase,times(1)).getPurchases();
    }
    @Test
    @DisplayName("Testing the average of multiple entries into the system")
    void averaging_purchases(){
        PurchaseDBO purchaseavg=mock(PurchaseDBO.class);
        PurchaseAgent average=new PurchaseAgent(purchaseavg);
        ArrayList<Purchase> buylist=new ArrayList<>();
        Purchase buy1=Purchase.make("Charlie",LocalDate.now(),30.00,"CA","STANDARD");
        Purchase buy2=Purchase.make("Jack",LocalDate.now(),70.00,"NY","NEXT_DAY");
        Purchase buy3=Purchase.make("Leo",LocalDate.now(),100.00,"IL","STANDARD");
        buylist.add(buy1);
        buylist.add(buy2);
        buylist.add(buy3);
        when(purchaseavg.getPurchases()).thenReturn(buylist);
        double averagecost=(buy1.getCost()+buy2.getCost()+buy3.getCost())/3;
        assertEquals(averagecost,average.averagePurchase());
    }
    @Test
    @DisplayName("Testing if the state is empty")
    void state_is_empty() {
        ShoppingCart list = new ShoppingCart();
        Bill receipt = TotalCostCalculator.calculate(list, " ", ShippingType.STANDARD);
        Purchase.make(" ", LocalDate.now(), receipt.total(), "", "STANDARD");
        list.clear();
    }
    @Test
    @DisplayName("Testing if the name of item is empty")
    void object_is_empty() {
        ShoppingCart list = new ShoppingCart();
        Bill receipt = TotalCostCalculator.calculate(list, "OR", ShippingType.STANDARD);
        Purchase.make(" ", LocalDate.now(), receipt.total(), "OR", "STANDARD");
        list.clear();
    }
    @Test
    @DisplayName("Testing both name of item and state are empty")
    void object_and_state_is_empty() {
        ShoppingCart list = new ShoppingCart();
        Bill receipt = TotalCostCalculator.calculate(list, " ", ShippingType.STANDARD);
        Purchase.make(" ", LocalDate.now(), receipt.total(), " ", "STANDARD");
        list.clear();
    }
}
