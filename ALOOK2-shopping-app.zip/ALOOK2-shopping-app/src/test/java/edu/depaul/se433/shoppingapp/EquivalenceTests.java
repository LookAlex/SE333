package edu.depaul.se433.shoppingapp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;


public class EquivalenceTests {
    @Test
    @DisplayName("Testing Illinois tax applies to an item if not throw a message back to user")
    void Illinois_tax(){
        assertEquals(3.3,TaxCalculator.calculate(55, "IL"),"Value not computed correctly");
    }
    @Test
    @DisplayName("Testing California tax applies to an item if not throw a message back to user")
    void California_tax(){
        assertEquals(2.4,TaxCalculator.calculate(40, "CA"),"Value not computed correctly");
    }
    @Test
    @DisplayName("Testing New York tax applies to an item if not throw a message back to user")
    void NewYork_tax(){
        assertEquals(1.5,TaxCalculator.calculate(25, "NY"), "Value not computed correctly");
    }
    @Test
    @DisplayName("Testing non taxing state/country tax applies to an item if not throw a message back to user")
    void non_tax_state(){
        assertEquals(0, TaxCalculator.calculate(45, "OR"), "This state is not included in this database");
    }
    @ParameterizedTest
    @MethodSource("StrongNormalTest")
    @DisplayName("Strong Normal Equivalence testing")
    void strong_normal_equivalence_test(String state,ShippingType shippingType,Double price, Double total){
        Double realtotal=TotalCostCalculator.calculate(price,state,shippingType);
        assertEquals(total,realtotal);
    }
    @ParameterizedTest
    @MethodSource("WeakNormalTest")
    @DisplayName("Weak Normal Equivalence testing")
    void weak_normal_equivalence_test(String state,ShippingType shippingType,Double price, Double total){
        if (price < 0.0||state.equals("")||state.equals("OR")||state.equals("UK")||total<0.0) {
            assertThrows(IllegalArgumentException.class, () -> TotalCostCalculator.calculate(price, state, shippingType));
        }

        else {
            Double realtotal = TotalCostCalculator.calculate(price, state, shippingType);
            assertEquals(total, realtotal);
        }
    }
    @ParameterizedTest
    @MethodSource("StrongRobustTest")
    @DisplayName("Strong Robust Equivalence Testing")
    void strong_robust_equivalence_test(String state,ShippingType shippingType,Double price, Double total){
        if (price < 0.0||state.equals("")||state.equals("OR")||state.equals("UK")||total<0.0) {
            assertThrows(IllegalArgumentException.class, () ->TotalCostCalculator.calculate(price, state, shippingType));
        }

        else {
            Double realtotal = TotalCostCalculator.calculate(price, state, shippingType);
            assertEquals(total, realtotal);
        }
    }
    @ParameterizedTest
    @MethodSource("WeakRobustTest")
    @DisplayName("Weak Robust Equivalence Testing")
    void weak_robust_equivalence_test(String state,ShippingType shippingType,Double price, Double total){
        if (price < 0.0||state.equals("")||state.equals("OR")||state.equals("UK")||total<0.0) {
            assertThrows(IllegalArgumentException.class, () -> TotalCostCalculator.calculate(price, state, shippingType));
        }

        else {
            Double realtotal = TotalCostCalculator.calculate(price, state, shippingType);
            assertEquals(total, realtotal);
        }
    }
    @ParameterizedTest
    @MethodSource("BoundaryTest")
    @DisplayName("Boundary Equivalence Testing")
    void boundary_test(String state,ShippingType shippingType,Double price, Double total) {
            Double realtotal = TotalCostCalculator.calculate(price, state, shippingType);
            assertEquals(total, realtotal);
    }
        private static Stream<Arguments> StrongNormalTest(){
        return Stream.of(
                //Normal IL strong tests
                Arguments.of("IL",ShippingType.NEXT_DAY,70.00,74.2),
                Arguments.of("IL",ShippingType.NEXT_DAY,42.00,71.02),
                Arguments.of("IL",ShippingType.STANDARD,9.99,21.1894),
                Arguments.of("IL",ShippingType.STANDARD,104.00,110.24),

                //Normal CA strong tests
                Arguments.of("CA",ShippingType.NEXT_DAY,56.00,59.36),
                Arguments.of("CA",ShippingType.NEXT_DAY,2.00,28.62),
                Arguments.of("CA",ShippingType.STANDARD,12.00,23.32),
                Arguments.of("CA",ShippingType.STANDARD,98.00,103.88),

                //Normal NY strong tests
                Arguments.of("NY",ShippingType.NEXT_DAY,17.00,44.519999999999996),
                Arguments.of("NY",ShippingType.NEXT_DAY,45.20,74.412),
                Arguments.of("NY",ShippingType.STANDARD,1.23,11.9038),
                Arguments.of("NY",ShippingType.STANDARD,89.60,94.976)
                );
        }
    private static Stream<Arguments> WeakNormalTest() {
        return Stream.of(
                //Weak tests taken from a section each of the strong tests
                Arguments.of("IL", ShippingType.NEXT_DAY, 14.70, 42.082),
                Arguments.of("CA", ShippingType.STANDARD, 54.00, 57.24),
                Arguments.of("NY", ShippingType.NEXT_DAY, 2.00, 28.62)
        );
    }
    private static Stream<Arguments> StrongRobustTest(){
        return Stream.of(
                //passing tests from the strong normal equivalence from before
                //Normal IL strong tests
                Arguments.of("IL",ShippingType.NEXT_DAY,70.00,74.2),
                Arguments.of("IL",ShippingType.NEXT_DAY,42.00,71.02),
                Arguments.of("IL",ShippingType.STANDARD,9.99,21.1894),
                Arguments.of("IL",ShippingType.STANDARD,104.00,110.24),

                //Normal CA strong tests
                Arguments.of("CA",ShippingType.NEXT_DAY,56.00,59.36),
                Arguments.of("CA",ShippingType.NEXT_DAY,2.00,28.62),
                Arguments.of("CA",ShippingType.STANDARD,12.00,23.32),
                Arguments.of("CA",ShippingType.STANDARD,98.00,103.88),

                //Normal NY strong tests
                Arguments.of("NY",ShippingType.NEXT_DAY,17.00,44.519999999999996),
                Arguments.of("NY",ShippingType.NEXT_DAY,45.20,74.412),
                Arguments.of("NY",ShippingType.STANDARD,1.23,11.9038),
                Arguments.of("NY",ShippingType.STANDARD,89.60,94.976),

                //IL strong robust with -1
                Arguments.of("IL",ShippingType.NEXT_DAY,2.00,-1.00),
                Arguments.of("IL",ShippingType.NEXT_DAY,-1.00,39.90),
                Arguments.of("IL",ShippingType.STANDARD,-1.00,45.90),
                Arguments.of("IL",ShippingType.STANDARD,17.00,-1.00),

                //CA strong robust with -1
                Arguments.of("CA",ShippingType.NEXT_DAY,89.00,-1.00),
                Arguments.of("CA",ShippingType.NEXT_DAY,-1.00,56.90),
                Arguments.of("CA",ShippingType.STANDARD,-1.00,14.00),
                Arguments.of("CA",ShippingType.STANDARD,53.00,-1.00),

                //NY strong robust with -1
                Arguments.of("NY",ShippingType.NEXT_DAY,34.00,-1.00),
                Arguments.of("NY",ShippingType.NEXT_DAY,-1.00,65.00),
                Arguments.of("NY",ShippingType.STANDARD,-1.00,95.00),
                Arguments.of("NY",ShippingType.STANDARD,62.00,-1.00),

                //OR not established in system state with regular shipping, price, and cost
                Arguments.of("OR",ShippingType.NEXT_DAY,34.00,50.00),
                Arguments.of("OR",ShippingType.NEXT_DAY,8.00,50.00),
                Arguments.of("OR",ShippingType.STANDARD,25.00,35.00),
                Arguments.of("OR",ShippingType.STANDARD,78.00,35.00),

                //OR not established in system and price and cost have -1 to
                Arguments.of("OR",ShippingType.NEXT_DAY,-1.00,85.00),
                Arguments.of("OR",ShippingType.NEXT_DAY,53.00,-1.00),
                Arguments.of("OR",ShippingType.STANDARD,73.70,-1.00),
                Arguments.of("OR",ShippingType.STANDARD,-1.00,3.00),

                //Out of the country not established in system with regular shipping, price, and cost
                Arguments.of("UK",ShippingType.NEXT_DAY,34.00,25.00),
                Arguments.of("UK",ShippingType.NEXT_DAY,56.00,25.00),
                Arguments.of("UK",ShippingType.STANDARD,7.00,25.00),
                Arguments.of("UK",ShippingType.STANDARD,85.00,25.00),

                //Out of country not established in system with -1 in price, and cost
                Arguments.of("UK",ShippingType.NEXT_DAY,-1.00,25.00),
                Arguments.of("UK",ShippingType.NEXT_DAY,14.00,-1.00),
                Arguments.of("UK",ShippingType.STANDARD,6.30,-1.00),
                Arguments.of("UK",ShippingType.STANDARD,-1.00,8.10),

                //No state entered but has information in the other categories
                Arguments.of("",ShippingType.NEXT_DAY,25.00,50.00),
                Arguments.of("",ShippingType.STANDARD,25.00,35.00),
                Arguments.of("",ShippingType.STANDARD,67.12,67.12),

                //No state and negative values
                Arguments.of("",ShippingType.NEXT_DAY,-1.00,12.00),
                Arguments.of("",ShippingType.NEXT_DAY,62.10,-1.00),
                Arguments.of("",ShippingType.STANDARD,89.60,-1.00),
                Arguments.of("",ShippingType.STANDARD,-1.00,70.00)
        );
    }
    private static Stream<Arguments> WeakRobustTest() {
        return Stream.of(
                //Weak tests from the ones above to make sure it first passes normal ones
                Arguments.of("IL", ShippingType.NEXT_DAY, 17.50, 45.05),
                Arguments.of("CA", ShippingType.STANDARD, 51.60, 54.696),
                Arguments.of("NY", ShippingType.NEXT_DAY, 1.90, 28.514),

                //Failing IL test
                Arguments.of("IL", ShippingType.NEXT_DAY, 1.00, -1.0),

                //Failing NY test
                Arguments.of("NY", ShippingType.STANDARD, -1.00, 25.0),

                //Failing CA test
                Arguments.of("CA", ShippingType.NEXT_DAY, 5.00, -1.0),

                //Failing OR test
                Arguments.of("OR", ShippingType.NEXT_DAY, 2.00, -1.0),
                //Failing Out of Country test
                Arguments.of("UK", ShippingType.STANDARD, -1.00, 25.0),
                //Failed test with no state info
                Arguments.of("",ShippingType.STANDARD,5.00,15.0),

                //Failed test with no state, and negative numbers
                Arguments.of("",ShippingType.NEXT_DAY,-1.00,12.00),
                Arguments.of("",ShippingType.NEXT_DAY,5.00,-1.00),
                Arguments.of("",ShippingType.STANDARD,29.10,-1.00),
                Arguments.of("",ShippingType.STANDARD,-1.00,70.00)
        );
    }
    private static Stream<Arguments> BoundaryTest () {
            return Stream.of(
                    //tests consisting of normal well under $25, well over $50
                    //tests of right under $50.00, at $50.00, right after $50.00
                    Arguments.of("IL", ShippingType.STANDARD, 9.99, 21.1894),
                    Arguments.of("IL", ShippingType.STANDARD, 49.99, 63.589400000000005),
                    Arguments.of("IL", ShippingType.STANDARD, 50.00, 63.60),
                    Arguments.of("IL", ShippingType.STANDARD, 50.01, 53.0106),
                    Arguments.of("IL", ShippingType.STANDARD, 60.00, 63.6)
            );
        }

}
